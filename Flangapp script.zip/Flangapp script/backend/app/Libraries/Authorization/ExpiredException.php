<?php namespace App\Libraries\Authorization;

class ExpiredException extends \UnexpectedValueException
{
}