<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Impeltech LLC">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Flangapp API</title>
    <!-- Bootstrap core CSS -->
    <link href="../theme/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="../theme/bootstrap/css/custom.css" rel="stylesheet">
    <script src="../theme/bootstrap/js/vue.min.js"></script>
</head>
<body>
<div class="d-flex justify-content-center align-items-center" style="height: 100vh">
    <img src="../theme/bootstrap/img/logosvg.svg" alt="" width="80" height="80">
</div>
<script src="../theme/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>